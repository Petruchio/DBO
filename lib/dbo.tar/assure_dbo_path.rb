$: << __dir__ unless $:.include? __dir__
